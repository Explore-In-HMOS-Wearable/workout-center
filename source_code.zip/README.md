# HIIT Squat Trainer

HIIT Squat Trainer is a HarmonyOS-based wearable app designed to help users perform high-intensity interval training focused on squats. The application uses the device's accelerometer to detect squat repetitions in real time and manages the training session based on user-defined duration and squat goals.

---

## Screenshots & Splash

### 1. Splash Page (GIF animation)

This screen displays a motivational animation (`splash.gif`) using a Lottie file when the app starts. After 5 seconds, it navigates to the main setup screen.

![Splash Page](screenshots/splash.gif)

---

### 2. Setup Page (Index.ets)

Here, the user inputs:
- **Workout duration** (seconds)
- **Squat target** (number of squats)

After setting these values, the user taps the “Start Workout” button.

![Index Page](screenshots/arrange.png)

![Index Page_Last](screenshots/arrangeDetail.png)

---

### 3. Workout Page (MainPage.ets)

Displays:
- A countdown timer (Gauge UI)
- Current and target squat count
- Pause/Reset buttons

Real-time squat tracking via the accelerometer. Navigation to result screen happens:
- when timer reaches 0, or
- target number of squats is completed.

![Main Workout Page](screenshots/timePage.png)

![Main Workout Page_Last](screenshots/timePage1.png)

---

### 4. Detail Page (DetailPage.ets)

Final screen showing:
- Target squats
- Completed squats
- Motivational message depending on performance
- Restart button

![Detail Page](screenshots/detail.png)

![Detail Page_Last](screenshots/DetailPage.png)

---

## Project Structure

```
main/
├── ets/
│   ├── animation/
│   │   └── LottieAnimation.ets
│   ├── core/
│   │   └── services/
│   │       ├── TimerService.ets
│   │       └── NavigationService.ets
│   ├── pages/
│   │   ├── SplashPage.ets
│   │   ├── Index.ets
│   │   ├── MainPage.ets
│   │   └── DetailPage.ets
│   └── util/
│       └── ConstantUI.ets
└── resources/
    ├── rawfile/
    │   └── splash.json
    └── assets/
        ├── splash.gif
        ├── index_screenshot.png
        ├── mainpage_screenshot.png
        └── detail_screenshot.png
```

---

## Technologies Used

- **Language**: ArkTS
- **UI Framework**: HarmonyOS ArkUI
- **Sensors**: Accelerometer (`@system.sensor`)
- **Routing**: `@ohos.router`, `@kit.ArkUI`
- **Animation**: Lottie JSON animation

---

## Author

Developed by Çağrı Yılmaz with ❤️ using HarmonyOS for wearable fitness solutions.
